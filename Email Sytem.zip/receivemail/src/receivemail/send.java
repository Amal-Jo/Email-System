package receivemail;


import java.util.Properties;
import java.util.Scanner;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
 
public class send {
   public static void main(String[] args) {
      //Declare recipient's & sender's e-mail id.
	   System.out.println("enter destination mail ");
	  Scanner Mail = new Scanner(System.in);
	  
      String sendrmailid = Config.EMAIL;	
      String destmailid =Mail.nextLine();
      
      System.out.println("subject: ");
      Scanner sub= new Scanner(System.in);
      String subject = sub.nextLine();
      
      System.out.println("write your Message:");
      Scanner cont = new Scanner(System.in);
      String content = cont.nextLine();
      
     //Mention user name and password as per your configuration
      final String uname = Config.EMAIL;
      final String pwd = Config.PASSSWORD;
     
      //Set property values
      Properties props = new Properties();
      props.put("mail.smtp.host", "smtp.gmail.com");
      props.put("mail.smtp.socketFactory.port", "465");
      props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
      props.put("mail.smtp.auth", "true");
      props.put("mail.smtp.port", "465");
      //Session emailSessionObj = Session.getDefaultInstance(props);   
      Session sessionobj = Session.getInstance(props,
         new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
               return new PasswordAuthentication(uname, pwd);
	   }
         });
 
      try {
	   //Create MimeMessage object & set values
	   Message messageobj = new MimeMessage(sessionobj);
	   messageobj.setFrom(new InternetAddress(sendrmailid));
	   messageobj.setRecipients(Message.RecipientType.TO,InternetAddress.parse(destmailid));
	   messageobj.setSubject(subject);
	   messageobj.setText(content);
	  //Now send the message
	   Transport.send(messageobj);
	   System.out.println("\n Your email sent successfully....");
      } catch (MessagingException exp) {
    	  System.out.println("Could,nt connect to the message store");
    	  exp.printStackTrace();
    	  //throw new RuntimeException(exp);
      }
   }
   }