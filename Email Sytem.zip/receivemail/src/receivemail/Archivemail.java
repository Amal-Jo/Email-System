package receivemail;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Properties;

import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Store;

public class Archivemail {
	
	 public static void main(String[] args) {
	     //Set mail properties and configure accordingly
	      String hostval = "smtp.gmail.com";
	      String mailStrProt = "pop3";
	      String uname = Config.EMAIL;
	      String pwd = Config.PASSSWORD;
	   
	      archiveMail(hostval, mailStrProt, uname, pwd);
	   }
	   public static void archiveMail(String hostval, String mailStrProt, String uname,String pwd) 
	   {
	      try {
	      //Set property values
	      Properties props = new Properties();
	      props.setProperty("mail.store.protocol", "imaps");
	      props.put("mail.smtp.host", "smtp.gmail.com");
	      props.put("mail.smtp.socketFactory.port", "465");
	      props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
	      props.put("mail.smtp.auth", "true");
	      props.put("mail.smtp.port", "465");
	      Session emailSessionObj = Session.getDefaultInstance(props);  
	      
	      //Create POP3 store object and connect with the server
	      Store storeObj = emailSessionObj.getStore("imaps");
	      storeObj.connect(hostval, uname, pwd);
	      System.out.println(storeObj);
	      
            //creating folders
	        Folder defaultFolder = storeObj.getDefaultFolder();
	        Folder archives = defaultFolder.getFolder("Archives");
	        archives.create(Folder.HOLDS_MESSAGES);   
	        
	        Folder spam = defaultFolder.getFolder("Spam");
	        spam.create(Folder.HOLDS_MESSAGES); 
	        
	        //printing folders
	        System.out.println("Availble folders");
	        Folder[] f = storeObj.getDefaultFolder().list();
		      for(Folder fd:f)
		    	System.out.println(">> "+fd.getName());
		      
		      
	      //Create folder object and open it in read-only mode
	      Folder emailFolderObj = storeObj.getFolder("INBOX");
	      emailFolderObj.open(Folder.READ_WRITE);
	      //emailFolderObj.copyMessages(messageObjs, archives);
	      
	      BufferedReader reader = new BufferedReader(new InputStreamReader(
	              System.in));
	      
	      //Fetch messages from the folder and print in a loop
	      Message[] messageobjs = emailFolderObj.getMessages();
	      System.out.println("inbox length"+messageobjs.length);
	      
	      emailFolderObj.copyMessages(messageobjs, archives);
	      archives.open(Folder.READ_WRITE);
	      
	      Message[] messageobjarchive = archives.getMessages();
	      //System.out.println("archive length"+messageobjarchive.length);
	     
	      System.out.println("Inbox messages.......");
	      for (int i = 0, n = messageobjarchive.length; i < n; i++) {
		         Message indvidual = messageobjarchive[i];
		         System.out.println("Printing individual messages");
		         System.out.println("No# " + (i + 1));
		         System.out.println("Email Subject: " + indvidual.getSubject());
		         System.out.println("Sender: " + indvidual.getFrom()[0]);
		         System.out.println("Content: " + indvidual.getContent().toString());
		         String subject = indvidual.getSubject();
		        
		         System.out.print("Do you want to remove it from archive [y/n] ? ");
		         String ans = reader.readLine();
		         if ("Y".equals(ans) || "y".equals(ans)) {
		        	 String archivemsg= indvidual.getSubject();
		        	 
		        	 String data[] = new String[messageobjarchive.length] ;
		        	
		        	 //String data[]=subject.split(subject);
		        	 System.out.println(Arrays.toString(data));
		        
			       // set the DELETE flag to true
		        	 indvidual.setFlag(Flags.Flag.DELETED, true);
		        	 System.out.println("removed file is " + subject);
		         } else if ("n".equals(ans)) {
			       continue;
		         }
		        
		      }
         System.out.println("archive length"+messageobjarchive.length);
	      
	      //Now close all the objects
	      emailFolderObj.close(false);
	      archives.close(false);
	     // destFolder.close(false);
	      storeObj.close();
	      } catch (NoSuchProviderException exp) {
	         exp.printStackTrace();
	      } catch (MessagingException exp) {
	         exp.printStackTrace();
	      } catch (Exception exp) {
	         exp.printStackTrace();
	      }
	   }

}
