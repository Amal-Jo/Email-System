package receivemail;

public class Config {
	public static final String EMAIL="thisisfortry38@gmail.com";
	public static final String PASSSWORD="Qwerty@123";

}
