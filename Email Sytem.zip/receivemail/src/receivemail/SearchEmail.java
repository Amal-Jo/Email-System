package receivemail;

import java.util.Properties;
import java.util.Scanner;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.search.SearchTerm;
public class SearchEmail {
	 public static void main(String[] args) {
	 //Set mail properties and configure accordingly
    String hostval = "smtp.gmail.com";
    String mailStrProt = "pop3";
    String uname = Config.EMAIL;
    String pwd = Config.PASSSWORD;
    //Declare search keyword
    System.out.println("enter your search here : ");
	 Scanner searchWord = new Scanner(System.in);
     String keyword = searchWord.nextLine();
    
    searchMail(hostval, mailStrProt, uname, pwd,keyword);
  
	} 
	 public static void searchMail(String hostval, String mailStrProt, String uname,String pwd,String keyword ) {
		 try {
		      //Set property values
		      Properties props = new Properties();
		      props.put("mail.smtp.host", "smtp.gmail.com");
		      props.put("mail.smtp.socketFactory.port", "465");
		      props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		      props.put("mail.smtp.auth", "true");
		      props.put("mail.smtp.port", "465");
		      Session emailSessionObj = Session.getDefaultInstance(props);  
		      
		      //Create POP3 store object and connect with the server
		      Store storeObj = emailSessionObj.getStore("pop3s");
		      storeObj.connect(hostval, uname, pwd);
		      
		      //Create folder object and open it in read-only mode
		      Folder emailFolderObj = storeObj.getFolder("INBOX");
		      emailFolderObj.open(Folder.READ_ONLY);
		      
		      //Create search search criteria
		      SearchTerm searchCond = new SearchTerm() {
		    	  @Override
	                public boolean match(Message message) {
	                    try {
	                        if (message.getSubject().contains(keyword)) {
	                            return true;
	                        }
	                    } catch (MessagingException ex) {
	                        ex.printStackTrace();
	                    }
	                    return false;
	                }
		    	  
		      };
		      
		      //Fetch searched messages from the folder and print in a loop
		      Message[] messageobjs = emailFolderObj.search(searchCond);
		      //System.out.println(messageobjs.length);
		 
		      for (int i = 0, n = messageobjs.length; i < n; i++) {
		         Message indvidualmsg = messageobjs[i];
		
		         System.out.println("Found Messages:");
		         System.out.println("No# " + (i + 1));
		         System.out.println("Email Subject: " + indvidualmsg.getSubject());
		         System.out.println("Sender: " + indvidualmsg.getFrom()[0]);
		         System.out.println("Content: " + indvidualmsg.getContent().toString());
		     
		        
		      }
		   
		      //Now close all the objects
		      emailFolderObj.close(false);
		      storeObj.close();
		      } catch (NoSuchProviderException exp) {
		          System.out.println("No provider");
		    	  exp.printStackTrace();
		      } catch (MessagingException exp) {
		          System.out.println("Could,nt connect to the message store");
		    	  exp.printStackTrace();
		      } catch (Exception exp) {
		         exp.printStackTrace();
		      }
		 
}
}
