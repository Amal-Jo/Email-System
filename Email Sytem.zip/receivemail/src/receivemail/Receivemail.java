package receivemail;
import java.util.Properties;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Store;
public class Receivemail{
	
   public static void main(String[] args) {
     //Set mail properties and configure accordingly
      String hostval = "smtp.gmail.com";
      String mailStrProt = "pop3";
      String uname = Config.EMAIL;
      String pwd = Config.PASSSWORD;
    // Calling checkMail method to check received 
      checkMail(hostval, mailStrProt, uname, pwd);
   }
   public static void checkMail(String hostval, String mailStrProt, String uname,String pwd) 
   {
      try {
      //Set property values
      Properties props = new Properties();
      props.put("mail.smtp.host", "smtp.gmail.com");
      props.put("mail.smtp.socketFactory.port", "465");
      props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
      props.put("mail.smtp.auth", "true");
      props.put("mail.smtp.port", "465");
      Session emailSessionObj = Session.getDefaultInstance(props);  
      
      //Create POP3 store object and connect with the server
      Store storeObj = emailSessionObj.getStore("pop3s");
      storeObj.connect(hostval, uname, pwd);
      
      //Create folder object and open it in read-only mode
      Folder emailFolderObj = storeObj.getFolder("INBOX");
      emailFolderObj.open(Folder.READ_ONLY);
      
      //Fetch messages from the folder and print in a loop
      Message[] messageobjs = emailFolderObj.getMessages();
      System.out.println(messageobjs.length);
 
      for (int i = 0, n = messageobjs.length; i < n; i++) {
         Message indvidualmsg = messageobjs[i];
         System.out.println("Printing individual messages");
         System.out.println("No# " + (i + 1));
         System.out.println("Email Subject: " + indvidualmsg.getSubject());
         System.out.println("Sender: " + indvidualmsg.getFrom()[0]);
         System.out.println("Content: " + indvidualmsg.getContent().toString());
        
      }
   
      //Now close all the objects
      emailFolderObj.close(false);
      storeObj.close();
      } catch (NoSuchProviderException exp) {
    	  System.out.println("No provider");
    	  exp.printStackTrace();
      } catch (MessagingException exp) {
    	  System.out.println("Could,nt connect to the message store");
    	  exp.printStackTrace();
      } catch (Exception exp) {
         exp.printStackTrace();
      }
   }
}